/**
 * Central capability progress source for FliHub, derived from Milestones.md
 * and docs/ROADMAP.md.
 *
 * The welcome page renders these cards so the team can see what works, what
 * is being built, and what is planned. Statuses are honest: a capability is
 * `complete` only after its user-visible workflow and access-control behavior
 * are verified end to end. No invented completion percentages.
 */

export type CapabilityStatus = 'planned' | 'in-progress' | 'ready-to-verify' | 'complete';

/** Narration readiness for a capability's walkthrough — tracked separately
 * from feature completion. */
export type NarrationStatus = 'not-started' | 'scripted' | 'recorded';

export interface Capability {
	title: string;
	description: string;
	/** Phase reference from Milestones.md, e.g. "Phase 1A". */
	milestone: string;
	status: CapabilityStatus;
	/** Short progress summary describing what is true today. */
	progress: string;
	/** Remaining or next work, when known. */
	next?: string;
	/** Link to the working feature inside the app (only when usable). */
	featureHref?: string;
	/** Walkthrough route; rendered as a link only when the video asset exists
	 * (see src/routes/+page.server.ts), otherwise "Walkthrough coming soon". */
	walkthroughHref?: string;
	/** Optional link text override — e.g. when a card reuses another phase's
	 * video and viewers should know what it covers. */
	walkthroughLabel?: string;
	/** Multiple reviewed walkthroughs on one milestone card; each is asset-gated. */
	walkthroughs?: { href: string; label: string }[];
	narration?: NarrationStatus;
}

export const capabilities: Capability[] = [
	{
		title: 'Organizations, invitations & roles',
		description:
			'Multi-organization membership with invitation-based access and Owner, Admin, Scorekeeper, and Viewer roles. Creating an account grants no organization access.',
		milestone: 'Phase 1A',
		status: 'complete',
		progress:
			'Registration, email verification, and server-validated sessions; organization creation and switching; copy-link invitations with verified-recipient acceptance; Owner/Admin/Scorekeeper/Viewer enforcement with atomic ownership transfer and an audit trail. Merged in PR #2 and verified by 15 integration tests plus a 9-step browser flow. Narrated walkthrough video available.',
		next: 'Invitation email delivery (copy-link only today).',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1a',
		narration: 'recorded'
	},
	{
		title: 'Configurable onboarding',
		description:
			'Starter templates (League, Race/Event, Custom) with capability-aware navigation that never bypasses role permissions.',
		milestone: 'Phase 1B',
		status: 'complete',
		progress:
			'League, Race/Event, and Custom starter templates with editable capability suggestions; a single shared capability catalog (browser and hooks read the same JSON); validated, audited configuration writes by Owners/Admins; race distances with explicit units; capability-aware navigation with honest planned/upcoming states. Implemented and merged in PR #4. Narrated walkthrough video available.',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1b',
		narration: 'recorded'
	},
	{
		title: 'Athlete identity',
		description:
			'Sport-neutral athlete records with organization-scoped identity, CSV import, and role-based management. Athletes are records, not accounts.',
		milestone: 'Phase 1C',
		status: 'complete',
		progress:
			'Create, edit, archive/restore, and CSV-import sport-neutral athletes from the organization navigation (Athletes capability). Private contact and eligibility fields (email, phone, eligibility notes) are managed and visible only to Owners/Admins; Scorekeepers/Viewers receive identity only. Direct API writes are capability-gated; disabling preserves records. Merged in PR #6; PR #7 prevents cross-organization reassignment of athlete records. Narrated walkthrough video available.',
		next: 'Identity matching rules for duplicate imports (open product decision); cross-organization athlete participation.',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1c',
		narration: 'recorded'
	},
	{
		title: 'Competition structure',
		description:
			'Leagues, seasons, divisions, team entries, and events with organization-scoped relationships. Teams enter seasons directly; events belong to one season or run independently.',
		milestone: 'Phase 1D',
		status: 'complete',
		progress:
			'Leagues, seasons (optional schedule dates), divisions, direct season team entries with an optional division assignment, and independent or season-linked events — managed from the organization navigation. Owner/Admin manage; Scorekeeper/Viewer read-only; capability-gated writes; cross-organization links and record reassignment rejected; duplicate season entries prevented; parent links immutable; archive/restore only. Merged in PR #9 and verified by 10 integration tests plus a browser acceptance flow. Narrated walkthrough video available.',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1d',
		narration: 'recorded'
	},
	{
		title: 'Season rosters & reserve pools',
		description:
			'Season rosters attached to team entries, separate reserve pools, and append-only event substitutions that never rewrite participation history.',
		milestone: 'Phase 1E',
		status: 'complete',
		progress:
			'Season rosters attached to team entries (one active spot per athlete per season, enforced down to concurrent writes, history preserved through archive), reserve pools with optional gender restriction (pilot configuration) structurally excluded from scheduling, and append-only substitutions that leave rosters intact — managed from the Teams & rosters page. Merged in PR #11 and verified by 11 integration tests, migration upgrade rehearsals, and a 17-assertion browser flow. Narrated walkthrough video available.',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1e',
		narration: 'recorded'
	},
	{
		title: 'Event operations',
		description:
			'Course layouts with holes and labeled positions, ordered event rounds, groups with team and athlete assignments, and per-group scorekeepers.',
		milestone: 'Phase 1F',
		status: 'complete',
		progress:
			'Courses with numbered/named holes and labeled positions (explicit units; venue records remain planned), ordered rounds whose named position must cover every active hole of its course (blank stays valid for planning; the chooser shows incomplete labels with their missing holes), event groups with one scorekeeper each (any member — score-entry permissions arrive in 1G), and group team/athlete assignments resolved from Phase 1E season rosters plus event-scoped substitutions: a reserve is assignable only for the event where the substitution applies, and assignments never change the season roster. Single-round events work with no intermission; the two-round demo format is verified separately. Merged in PR #14 and verified by 9 integration tests plus two browser flows (19 + 21 assertions). Demo counts are pilot configuration. Narrated walkthrough video available.',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1f',
		narration: 'recorded'
	},
	{
		title: 'Disc golf demonstration event',
		description:
			'A two-round event on a nine-hole course with red/blue basket positions, six groups, and assigned scorekeepers.',
		milestone: 'Phase 1F',
		status: 'complete',
		progress:
			'Verified end to end (2026-11-07, tests/e2e/demo-sixgroup.spec.mjs on a disposable stack): the exact Phase 1F demo fixture — one course with nine par-3 hole records (red/blue positions within 220–425 ft, hole 8 keeping its placeholder demo name), a Red round, an intermission, and a Blue round replaying the same nine holes, 12 teams of one male and one female rostered athlete, separate reserve pools, and six groups of two teams with an assigned scorekeeper — scored by the scorekeeper and taken through submission, official approval, and publication. All 12 scorecards (6 groups × 2 rounds) submitted; all 24 athletes have exactly 9 scores in each nine-hole round (432 scores); every published per-athlete, per-round, and per-team total matches the submitted strokes; and a signed-out browser sees the published result and season standings reflecting the event exactly once with matching totals and shared ranks on equal totals.',
		next: 'The fantasy portions of the demonstration (membership, draft, scoring, corrections) arrive with Phases 2A–2C.',
		// Reuses the approved Phase 1F recording — it covers the event SETUP
		// (course, rounds, groups), not scoring; the label says so.
		walkthroughHref: '/walkthroughs/phase1f',
		walkthroughLabel: 'Watch event setup walkthrough (Phase 1F)'
	},
	{
		title: 'Mobile scorekeeping',
		description:
			'Phone-friendly scoring with per-hole strokes and a Draft → Submitted workflow. Missing scores never become zero.',
		milestone: 'Phase 1G',
		status: 'complete',
		progress:
			'Phone-first scorecard resolved from the Phase 1F setup: event, rounds with hole counts derived from their course (the FLI demo shows Round 1 · 9 holes · Red, an intermission, Round 2 · 9 holes · Blue — the second pass displays 10–18 while scores stay keyed by round and physical hole), groups, teams, and athletes. Per-athlete integer strokes with draft save/resume; missing scores are visible, block submission, and are never stored as zero; every change is logged with its author; Submitted locks against silent overwrites with Owner/Admin-only reopen requiring a recorded reason; once scoring starts, a group\u2019s athlete lineup is fixed. Entry requires the Scorekeeper role plus a group assignment in the event (event-wide, per the agreed cross-group rule) — Viewers stay read-only even when listed as a group\u2019s scorekeeper. Merged in PR #17 and verified by 5 integration tests and a 21-assertion phone browser flow. Narrated walkthrough video available.',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1g',
		narration: 'recorded'
	},
	{
		title: 'Official results & corrections',
		description:
			'Approval and publication with versioned corrections that preserve author, time, reason, and previous values.',
		milestone: 'Phase 1H',
		status: 'complete',
		progress:
			'Event-level official results reviewed and approved by Owners/Admins only when every (round × group) scorecard is Submitted — missing scores block approval and never count as zero. Approval snapshots per-athlete and per-team totals into an append-only version; publication stamps it; while approved or published, the event\u2019s scorecards are locked. There is no unpublish: reopening requires a recorded reason, visibly marks the result under correction (the last published version stays on record), and corrections flow through the scorecard reopen, reapproval (exactly one new version carrying the reason), and republication. Version and audit collections reject all client writes, so approval, publication, author, and correction metadata cannot be forged. Merged in PR #20 and verified by 5 integration tests (72/72 full suite) plus a browser flow with viewer-continuity assertions at every stage. Competition standings and public pages consume the published versions (Phase 1I); fantasy consumption remains planned; the playoff shootout stays documentation-only. Narrated walkthrough video available.',
		next: 'Fantasy consumes published results only (Phase 2).',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1h',
		narration: 'recorded'
	},
	{
		title: 'Competition standings',
		description: 'Standings produced only from approved and published official results.',
		milestone: 'Phase 1I',
		status: 'complete',
		progress:
			'Merged in PR #22 (D17): seasons sum total strokes across events with a currently published official result — lowest total leads; a team or athlete is ranked only with a result in every counted event (incomplete participation shows Unranked with its strokes and an event count such as 1 of 2 — missing results never add strokes); equal totals among ranked rows share a position, and scores display relative to par. Pending corrected versions never count; a republished correction replaces the previous contribution exactly once. Members see standings on the Standings capability page; the public page shows them for per-record published events only. Verified by 6 integration tests (78/78 full suite) plus a signed-out browser flow. Narrated walkthrough video available.',
		next: 'Fantasy consumes published results only (Phase 2); the full six-group disc golf demonstration is verified (see the Disc golf demonstration event card).',
		featureHref: '/organizations',
		walkthroughHref: '/walkthroughs/phase1i',
		narration: 'recorded'
	},
	{
		title: 'Fantasy league & snake draft',
		description:
			'A six-person fantasy league with per-event, eligibility-aware four-round snake drafts and a configurable pick timer.',
		milestone: 'Phases 2A–2B',
		status: 'complete',
		progress:
			'Implemented and verified locally on the Phases 2A–2B branch (D18): private leagues with an invite → accept → approve seat lifecycle fully independent of organization staff roles; one fresh four-round snake draft per event with a randomly drawn, persisted first-round order that reverses each round (24 picks); real Athlete records shown with their real event teams; server-enforced turn order, event eligibility, one selection per athlete, and rosters of exactly 2 MPO + 2 FPO; 7/15/30-second pick clocks with slot-aware timeout auto-picks from per-draft rankings; server-owned turns and deadlines so managers reconnect to the same board, and a manual pick racing the timeout produces exactly one pick; designated event substitutes take completed roster slots with the original pick preserved. Event activation durably blocks manual and timeout picks and flags unfinished drafts without changing their selections. Rounds 3–4 filter the on-clock participant’s pool to selectable athletes. Fresh closeout verification: 11 focused integration tests and draft/playback browser checks passed. Two narrated walkthroughs are available.',
		next: 'Fantasy scoring, explanations, correction processing, and completed-roster scoring-lock verification (Phase 2C).',
		featureHref: '/organizations',
		walkthroughs: [
			{ href: '/walkthroughs/phase2ab-setup', label: 'Watch League Setup & Draft Prep' },
			{ href: '/walkthroughs/phase2ab-live', label: 'Watch Live Draft & Roster Rules' }
		]
	},
	{
		title: 'Fantasy scoring & explanations',
		description:
			'Versioned fantasy points from published results, with visible calculations and correction-safe reprocessing that never duplicates points.',
		milestone: 'Phase 2C',
		status: 'planned',
		progress: 'Not started.'
	},
	{
		title: 'Branded public pages',
		description:
			'Hosted public organization pages, followed later by website embeds and a read-only public API.',
		milestone: 'Phases 1I, 2E–2F',
		status: 'complete',
		progress:
			'The hosted page is merged (PR #22): a unique reserved slug at /o/<slug>, organization branding (name, tagline, logo URL, theme colors), capability-gated sections, and explicit per-record publication enforced by a single shared publication-rule layer — unpublished pages are hidden 404s, private athlete contact data is never readable publicly, and corrected results carry a dated Corrected badge. Website embeds (2E) and the read-only public API (2F) will reuse the same rules verbatim and remain planned. Narrated walkthrough video available.',
		next: 'Embeds and the public API reuse the Phase 1I publication rules (Phases 2E–2F).',
		walkthroughHref: '/walkthroughs/phase1i',
		walkthroughLabel: 'Watch walkthrough (shared with Competition standings)',
		narration: 'recorded'
	}
];

export const capabilityStatusMeta: Record<CapabilityStatus, { label: string; badgeClass: string }> =
	{
		planned: {
			label: 'Planned',
			badgeClass: ''
		},
		'in-progress': {
			label: 'In progress',
			badgeClass: 'border-transparent bg-blue-600 text-white'
		},
		'ready-to-verify': {
			label: 'Ready to verify',
			badgeClass: 'border-transparent bg-amber-500 text-white'
		},
		complete: {
			label: 'Complete',
			badgeClass: 'border-transparent bg-green-600 text-white'
		}
	};
